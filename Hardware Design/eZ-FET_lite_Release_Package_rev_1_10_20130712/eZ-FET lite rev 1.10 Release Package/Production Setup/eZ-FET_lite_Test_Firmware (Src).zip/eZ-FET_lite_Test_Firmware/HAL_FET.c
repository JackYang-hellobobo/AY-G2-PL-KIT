//*****************************************************************************
//
// Copyright (C) 2012 - 2013 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the
//  distribution.
//
//  Neither the name of Texas Instruments Incorporated nor the names of
//  its contributors may be used to endorse or promote products derived
//  from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//****************************************************************************

#include "HAL_FET.h"

void Init_Clock(void)
{
    WDTCTL = WDTPW + WDTHOLD;
    __delay_cycles(100000); //settle down
   
    P5SEL |= BIT2+BIT3; // enable XT2 pins for F5528
    SetVCore(3);      
    __delay_cycles(100000); //settle down

    // Use the REFO oscillator to source the FLL and ACLK
    UCSCTL3 = (UCSCTL3 & ~(SELREF_7)) | (SELREF__REFOCLK);
    UCSCTL4 = (UCSCTL4 & ~(SELA_7)) | (SELA__REFOCLK);
    
    // MCLK will be driven by the FLL (not by XT2), referenced to the REFO
    XT2_Start(XT2DRIVE_1);  // Start the "USB crystal"
    __delay_cycles(100000); //settle down
    __bis_SR_register(SCG0);
    UCSCTL3 = SELREF_5+FLLREFDIV_2;         // Select XT2 reference (4MHz) divided by 4 -> FLLRef = 1MHz
    UCSCTL0 = 0x0000;                       // Set lowest possible DCOx, MODx 
    UCSCTL1 = DCORSEL_5;                    // Select DCO range 24-54MHz operation 
    UCSCTL2 =  FLLD_1 + 17;                 // Set DCO Multiplier for 18MHz  
                                            // (N + 1) * FLLRef = Fdco
                                            // (17 + 1) * 1MHz = 18MHz
                                            // Set FLL Div = fDCOCLK/2
    __bic_SR_register(SCG0);                // Enable the FLL control loop
    unsigned int timeout = 0xFFFF;
    do{
        UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + XT1HFOFFG + DCOFFG); //Clear XT2,XT1,DCO fault flags
        SFRIFG1 &= ~OFIFG;                                      //Clear fault flags
    }while ((SFRIFG1 & OFIFG) && (--timeout>0));
    if (timeout == 0)
    {
      
      unsigned long cnt = 0;
      while(0)
      {
        if (cnt-- == 0) 
        {
          LED0_TOGGLE;
          cnt = 500000;
        }
      }
      
      // Force WDT reset if clock system could not be started
      WDTCTL = 0xDEAD;
    }
    
    UCSCTL4 = SELA__REFOCLK+ SELS__XT2CLK + SELM__DCOCLKDIV;  //MCLK=18MHz, SMCLK=4MHz, ACLK=32768Hz
    __delay_cycles(100000);
}

void Init_Clock_20mhz(void)
{
    __bis_SR_register(SCG0);
    UCSCTL3 = SELREF_5+FLLREFDIV_2;         // Select XT2 reference (4MHz) divided by 4 -> FLLRef = 1MHz
    UCSCTL0 = 0x0000;                       // Set lowest possible DCOx, MODx 
    UCSCTL1 = DCORSEL_5;                    // Select DCO range 24-54MHz operation 
    UCSCTL2 =  FLLD_1 + 19;                 // Set DCO Multiplier for 18MHz  
                                            // (N + 1) * FLLRef = Fdco
                                            // (19 + 1) * 1MHz = 20MHz
                                            // Set FLL Div = fDCOCLK/2
    __bic_SR_register(SCG0);                // Enable the FLL control loop
    unsigned int timeout = 0xFFFF;
    do{
        UCSCTL7 &= ~(XT2OFFG + XT1LFOFFG + XT1HFOFFG + DCOFFG); //Clear XT2,XT1,DCO fault flags
        SFRIFG1 &= ~OFIFG;                                      //Clear fault flags
    } while ((SFRIFG1 & OFIFG) && (--timeout>0));
    if (timeout == 0)
    {
      // Force BOR if clock system could not be started
      PMMCTL0 = 0xA504;
    }  
    
    UCSCTL4 = SELA__REFOCLK+ SELS__XT2CLK + SELM__DCOCLKDIV;
    __delay_cycles(1000000);
}

void Init_Ports(void)
{
  // Ports all back to reset state
  P1DIR = 0;  P2DIR = 0;  P3DIR = 0;    // Reset all ports direction to be inputs
  P4DIR = 0;  P5DIR = 0;  P6DIR = 0;
  P1SEL = 0;  P2SEL = 0;  P3SEL = 0;    // Reset all ports alternate function
  P4SEL = 0;  P5SEL = 0;  P6SEL = 0;
  P1OUT = 0;  P2OUT = 0;  P3OUT = 0;    // Reset all port output registers
  P4OUT = 0;  P5OUT = 0;  P6OUT = 0;

  // Port1
  //  P1.0 -> n/c
  //  P1.1 -> n/c
  //  P1.2 -> LED0
  //  P1.3 -> LED1
  //  P1.4 -> n/c
  //  P1.5 -> n/c
  //  P1.6 -> n/c
  //  P1.7 -> n/c
  P1DIR = (BIT0+BIT1+BIT2+BIT3+BIT4+BIT5+BIT6+BIT7);	// set pins to output direction

  // Port2
  //  P2.0 -> n/c
  //  P2.1 -> n/c
  //  P2.2 <- n/c
  //  P2.3 -> n/c
  //  P2.4 -> n/c
  //  P2.5 -> n/c
  //  P2.6 <- UART_RTS
  //  P2.7 -> UART_CTS
  P2DIR = (BIT0+BIT1+BIT3+BIT4+BIT5+BIT7); // set pins to output direction

  // Port3
  //  P3.0 <- n/c
  //  P3.1 <- n/c
  //  P3.2 -> n/c
  //  P3.3 -> UART_RXD
  //  P3.4 <- UART_TXD
  //  P3.5 -> n/c
  //  P3.6 -> n/c
  //  P3.7 -> n/c
  P3DIR = (BIT5+BIT6+BIT7);	// set pins initially to output direction

  // Port4
  //  P4.0 -> n/c
  //  P4.1 -> n/c
  //  P4.2 -> n/c
  //  P4.3 -> n/c
  //  P4.4 -> n/c
  //  P4.5 -> n/c
  //  P4.6 -> n/c
  //  P4.7 -> n/c
  P4DIR = (BIT0+BIT1+BIT2+BIT3+BIT4+BIT5+BIT7);	// set pins initially to output direction

  // Port5
  //  P5.0 -> VREF+ (output of reference voltage to ADC)
  //  P5.1 -> n/c
  //  P5.2 <- XT2
  //  P5.3 -> XT2
  //  P5.4 -> n/c
  //  P5.5 -> n/c
  //  P5.6 -> n/c
  //  P5.7 -> n/c
  P5DIR = (BIT0+BIT1+BIT2+BIT3+BIT4+BIT5+BIT6+BIT7);	// set pins initially to output direction
  P5SEL = (BIT0);

  // Port6
  //  P6.0 <- A_VBUS (input to ADC channel A0)
  //  P6.1 <- A_VCCOUT
  //  P6.2 <- A_VCCTARGET
  //  P6.3 -> n/c
  //  P6.4 <-> n/c
  //  P6.5 <-> n/c
  //  P6.6 <-> n/c 
  //  P6.7 <-> n/c 
  P6DIR = (BIT3+BIT4+BIT5+BIT6+BIT7);	// set pins initially to output direction
  P6SEL = (BIT0+BIT1);

  // Enable Vref=2.5V for ADC  
  REFCTL0 |= REFMSTR;
  REFCTL0 |= REFVSEL1;
  REFCTL0 |= REFON;

  // Configure ADC12
  // select channel and do conversion
  ADC12CTL0 = ADC12ON + ADC12SHT02;            // Turn on ADC12, set sampling time
  ADC12CTL1 = ADC12SHP;                        // Use sampling timer  
  ADC12MCTL0  = ADC12SREF_1 + 0;               // select Vref and analog channel A0    
}



//Measures supply voltages and checks if they are in the right interval
//Checks XT2 frequency (compared with REFO)  
void Test_MSP0(void)
{
    //Get die info from Device Descriptor Table
    unsigned int x = *((unsigned int*)DIEXPOS_ADDRESS);
    Add_Test_Result(TEST_LOTID, TEST_PASS, *((unsigned long*)LOTID_ADDRESS));
    Add_Test_Result(TEST_DIEXY, TEST_PASS, ((unsigned long)x<<16) + *((unsigned int*)DIEYPOS_ADDRESS));
    
    unsigned int compare, oldcapture, timeout = 0;    
    
    LED0_OFF
    LED1_OFF
    
    //Init measurement of XT2 frequency
    TA2CCTL2 = (CM_1 | CCIS_1 | CAP );                            // Rising edge, ACLK, Capture
    TA2CTL = (TASSEL__SMCLK | MC__CONTINOUS | TACLR);            // SMCLK, cont-mode, clear MC_2
    
    //The timer runs off SMCLK and waits to capture an ACLK toggle event: when this happens, we count how many 
    //SMCLK cycles occured and compare them with the expected number of cycles (4MHz/32768Hz =~ 122)    
    
    while (1) 
    {
        while (!(CCIFG & TA2CCTL2));       // Wait until capture occured
        TA2CCTL2 &= ~CCIFG;                // Capture occured, clear flag
        compare = TA2CCR2;                 // Get current captured SMCLK
        compare = compare - oldcapture;    // SMCLK difference
        oldcapture = TA2CCR2;              // Save current captured  SMCLK
              
        if(compare >= XT2_REFO_DELTA_LOW && compare <= XT2_REFO_DELTA_HIGH)
        {
            Add_Test_Result(TEST_XT2, TEST_PASS, (long)compare*32768);
            break;                            // If equal, leave "while(1)"
        }                 
        else if (compare < XT2_REFO_DELTA_LOW) 
        {
           timeout++;
        }
        else if (compare > XT2_REFO_DELTA_HIGH)
        {
           timeout++;
        }
        if(timeout>100)                    //Too many attempts, the oscillator is definitely faulty
        {
            testResult = TEST_FAIL;
            Add_Test_Result(TEST_XT2, TEST_FAIL, (long)compare*32768);
            break;
        }
    }
    TA2CCTL2 = 0;                        // Stop TACCR0
    TA2CTL = 0;                          // Stop Timer_A
    
    // Measure VBUS on A0 (P6.0), average result
    int i = 0;
    float vbus_mv = 0, vbus_mv0;
    
    ADC12CTL0  &= ~ADC12ENC;              // Disable conversion, write controls
    ADC12MCTL0  = ADC12SREF_1 + ADC12INCH_0;  // select Vref and analog channel Ax
    ADC12CTL0  |= ADC12ENC;               // Enable conversions
    __delay_cycles((15*90));
    
    for (i=0; i<100; i++)
    {
            ADC12CTL0 |= ADC12SC;            // Start conversion
            while (ADC12CTL1 & ADC12BUSY);   // Wait for finish

            // Calculate VBUS based on Vref+=2.5V, R51=240kOhm, R52=150kOhm (MSP-FET), R124=240kOhm R125=150kOhm (EZ-FET)
            vbus_mv0 = ((int)ADC12MEM0) * (2500.0f / 4096.0f);
            vbus_mv0 = (vbus_mv0 * (240 + 150)) / 150;
            vbus_mv+=vbus_mv0;  
    }
    vbus_mv/=100;
    if ((vbus_mv > (float)VBUS_LOW) && (vbus_mv < (float)VBUS_HIGH))     //Check if voltage is between tolerance
    {
        Add_Test_Result(TEST_VBUS, TEST_PASS, (long)vbus_mv);
    }
    else
    {
        testResult = TEST_FAIL;
        Add_Test_Result(TEST_VBUS, TEST_FAIL, (long)vbus_mv);
    }
    
    // Measure VCC_SUPPLY / VCC_EZFET on A1 (P6.1), average result
    float vsupply_mv = 0, vsupply_mv0;    
    ADC12CTL0  &= ~ADC12ENC;              // Disable conversion, write controls
    ADC12MCTL0  = ADC12SREF_1+ADC12INCH_1;  // select Vref and analog channel Ax
    ADC12CTL0  |= ADC12ENC+ADC12SHT0_15;               // Enable conversions
    ADC12CTL1  = ADC12SHP+ ADC12DIV_7 + ADC12SSEL_1;  
    __delay_cycles((15*90));
    ADC12CTL0 |= ADC12ENC;               
   
    for (i=0; i<100; i++)
    {
          ADC12CTL0 |= ADC12SC; 
          while (ADC12CTL1 & ADC12BUSY);	     

          // Calculate VCC_SUPPLY based on Vref+=2.5V, R65=470kOhm, R15=470kOhm (MSP-FET), R112=220kOhm R113=220kOhm (EZ-FET)
          vsupply_mv0 = ((int)ADC12MEM0) * (2500.0f / 4096.0f);
          vsupply_mv0 = (vsupply_mv0 * (220 + 220)) / 220;
          vsupply_mv +=vsupply_mv0;
    }    
    vsupply_mv/=100;

    if ((vsupply_mv > (float)VSUPPLY_LOW) && (vsupply_mv < (float)VSUPPLY_HIGH)) //Check if voltage is between tolerance
    {
        Add_Test_Result(TEST_VOUT, TEST_PASS, (long)vsupply_mv);
    }
    else
    {
        testResult = TEST_FAIL;
        Add_Test_Result(TEST_VOUT, TEST_FAIL, (long)vsupply_mv);
    }      
}


//******************************************************************************
// This code will be placed at 0xF000, so it's safe to place a BP 
//******************************************************************************
int spin = 0; // required, otherwise CGT will optimize breakpoint function!
#ifdef __CCS__
#pragma FUNC_CANNOT_INLINE (breakpoint);
#pragma CODE_SECTION(breakpoint, ".breakpoint")
void breakpoint(void)
#endif
#ifdef  __IAR_SYSTEMS_ICC__
#pragma inline=never
void breakpoint(void) @ "FLASH_BP"
#endif
#ifdef __GCC__
void  __attribute__ ((section ("sbreakpoint"), noinline)) breakpoint(void);
void breakpoint(void)
#endif
{
   // Empty
   if (spin == 1) 
   { 
    while(1) { }
   }
}

// Timer0 A0 interrupt service routine, flashes leds during FPGA programming
#pragma vector=TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR(void)
{
    if(LED0_PORT_OUT && LED0_BIT)
       LED1_TOGGLE
    if(LED1_PORT_OUT && LED1_BIT)
       LED0_TOGGLE;
}