//*****************************************************************************
//
// Copyright (C) 2012 - 2013 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//  Redistributions of source code must retain the above copyright
//  notice, this list of conditions and the following disclaimer.
//
//  Redistributions in binary form must reproduce the above copyright
//  notice, this list of conditions and the following disclaimer in the
//  documentation and/or other materials provided with the
//  distribution.
//
//  Neither the name of Texas Instruments Incorporated nor the names of
//  its contributors may be used to endorse or promote products derived
//  from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//****************************************************************************

#ifndef HAL_FET_H_
#define HAL_FET_H_

#include <msp430f5528.h> 

#include <msp430.h>
#include "HAL_UCS.h"
#include "HAL_PMM.h"

// LED0 red
#define LED0_BIT		( BIT2 )
#define LED0_PORT_OUT	        ( P1OUT )
#define LED0_ON			{ LED0_PORT_OUT |= LED0_BIT; }
#define LED0_OFF		{ LED0_PORT_OUT &= ~LED0_BIT; }
#define LED0_TOGGLE		{ LED0_PORT_OUT ^= LED0_BIT; }

// LED1 green
#define LED1_BIT		( BIT3 )
#define LED1_PORT_OUT	        ( P1OUT )
#define LED1_ON			{ LED1_PORT_OUT |= LED1_BIT; }
#define LED1_OFF		{ LED1_PORT_OUT &= ~LED1_BIT; }
#define LED1_TOGGLE		{ LED1_PORT_OUT ^= LED1_BIT; }

//Test values
#define XT2_REFO_DELTA          123       // XT2-REFO Comparison: 4MHz/32768Hz =~ 123
#define XT2_REFO_DELTA_LOW      121
#define XT2_REFO_DELTA_HIGH     125
#define VBUS_LOW                4750  
#define VBUS_HIGH               5250
#define VSUPPLY_NOM             2800
#define VSUPPLY_LOW             (VSUPPLY_NOM*0.95)      
#define VSUPPLY_HIGH            (VSUPPLY_NOM*1.05)

// Addresses taken from 5528/6638 Device Descriptor Table (see datasheet)
#define LOTID_ADDRESS           0x1A0A
#define DIEXPOS_ADDRESS         0x1A0E
#define DIEYPOS_ADDRESS         0x1A10

#define USB_MCLK_FREQ           18000000  // MCLK frequency of MCU, in Hz

// -------------------------------------------------------
// Test framework
// 0: Global pass / fail
// 1-6: Test 1 [1 type, 1 result, 4 value)
// ...

#define TEST_ARRAY_LOCATION         0x2400
#define TEST_COUNT                  20
#define TEST_SIZE                   6
#define TEST_ARRAY_LENGTH           (TEST_COUNT*TEST_SIZE+1)
#define TEST_TYPE                   0
#define TEST_RESULT                 1
#define TEST_VALUE_3                2
#define TEST_VALUE_2                3
#define TEST_VALUE_1                4
#define TEST_VALUE_0                5

#define TEST_PASS                   0xAA
#define TEST_FAIL                   0x55

// List of test types
typedef enum testType
{
    // Test over signature
    TEST_OVER = 0,

    // Common tests
    TEST_LOTID,
    TEST_DIEXY,
    TEST_XT2,

    // Host MCU tests
    TEST_VBUS,
    TEST_VOUT,
    TEST_VJTAG,
    TEST_DCDC_MCU,
    TEST_FPGA,
    TEST_UART,
    TEST_STANDBY_CURRENT,

    // Target MCU tests
    TEST_VOLTAGE1,
    TEST_VOLTAGE2,
    TEST_VOLTAGE3,
    TEST_VOLTAGE4,
    TEST_XT,
    TEST_DISPLAY1,
    TEST_DISPLAY2,
    TEST_DISPLAY3,
    TEST_DISPLAY4,
    TEST_LED1,
    TEST_LED2,
    TEST_LED3,
    TEST_LED4,
    TEST_SWITCH1,
    TEST_SWITCH2,
    TEST_SWITCH3,
    TEST_SWITCH4,
    TEST_POWER1,
    TEST_POWER2,
    TEST_POWER3,
    TEST_POWER4,
    TEST_CAPTOUCH1,
    TEST_CAPTOUCH2,
    TEST_CAPTOUCH3,
    TEST_CAPTOUCH4,
    TEST_UART1,
    TEST_UART2,
    TEST_UART3,
    TEST_UART4
} testType_t;


extern __no_init unsigned char testResultArray[TEST_ARRAY_LENGTH] @ TEST_ARRAY_LOCATION;
extern unsigned char testIndex;
extern unsigned char testResult;
extern void Init_Test(void);
extern void Add_Test_Result(testType_t type, unsigned char result, unsigned long value);
extern void Close_Test(unsigned char result);
// -------------------------------------------------------


// API functions
void Init_Clock(void);
void Init_Clock_20mhz(void);
void Init_Ports(void);
void Init_DCDC(void);
void Test_MSP0(void);   
void Program_MSP1(void);
void breakpoint(void);

#endif /* HAL_MSPFET_H_ */
